<?php $__env->startSection('titulo'); ?>
Ver Profesor <?php echo e($profesor->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('profesores/')); ?>">Profesores</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page"><?php echo e($profesor->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center ">
<?php $__env->startSection('tituloCabezera'); ?> 
  Mostrar Profesor <?php echo e($profesor->nombre); ?>

<?php $__env->stopSection(); ?>
  <div class="card ">
    <div class="card-body ">
      <h5 class="card-title"><?php echo e($profesor->nombre); ?></h5>
      <h6 class="card-subtitle mb-2 text-muted"><?php echo e($profesor->apellidos); ?></h6>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Departamento</th>
              <th scope="col">Especialidad</th>
              <th scope="col">Cargo</th>
              <th scope="col">Codigo</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><?php echo e($profesor->id); ?></td>
              <td><?php echo e($profesor->departamento); ?></td>
              <td><?php echo e($profesor->especialidad); ?></td>
              <td><?php echo e($profesor->cargo); ?></td>
              <td><?php echo e($profesor->codigo); ?></td>
            </tr>
          </tbody>
        </table>
      </div>
      <h5 class="card-title ">Observaciones</h5>
      <p class="card-text"><?php echo e($profesor->observaciones); ?></p>
      <h5 class="card-title ">Imagen</h5>
      <img class="border d-inline border " width="250px"  src="<?php echo e(url('/').'/storage/'.$profesor->rutaImagen/*url('../').'/storage/app/public/'.$profesor->rutaImagen*/); ?>" alt=""><br>
      <hr>
      <a class='btn btn-warning' href='<?php echo e(url('/horario/profesor/').'/'.$profesor->id); ?>' role='button'>Horario</a>
      <a class='btn btn-primary' href='<?php echo e($profesor->id); ?>/edit' role='button'>Editar</a>
      <!--<a class='btn btn-danger' href="<?php echo e(route('profesores.destroy', [$profesor->id])); ?>" role='button'>Borrar</a>-->
      <div class="d-inline">
        <form class="d-inline" method="POST" action="<?php echo e(url('profesores/').'/'.$profesor->id); ?>">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

          <input type="submit" class="btn btn-danger" value="Eliminar">
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>