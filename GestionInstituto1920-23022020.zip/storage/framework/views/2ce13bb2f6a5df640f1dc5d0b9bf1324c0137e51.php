<?php $__env->startSection('titulo'); ?>
Ver aula <?php echo e($aula->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<style>
  input,
  textarea {
    text-align: center;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('aulas/')); ?>">Aulas</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page"><?php echo e($aula->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center ">
  <?php $__env->startSection('tituloCabezera'); ?>
    Mostrar Aula: <?php echo e($aula->nombre); ?>

  <?php $__env->stopSection(); ?>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre</label>
      <input disabled type="name" class="form-control" value="<?php echo e($aula->nombre); ?>" name="nombre" id="inputEmail4">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Numero</label>
      <input disabled type="number" class="form-control" value="<?php echo e($aula->numero); ?>" name="numero" id="inputPassword4">
    </div>
  </div>

  <div class="form-row text-center">
    <div class="form-group col-md-12 ">
      <?php if($aula->reservable == false): ?>
         <input disabled class='text-center' data-offstyle='danger' data-onstyle='success' data-toggle='toggle' id='chkToggle2' type='checkbox' data-on='Se puede Reservar' data-off='No se puede Reservar' data-width='95' name='reservable' >
            
      <?php else: ?>
        <input disabled class='text-center' data-offstyle='danger' data-onstyle='success' data-toggle='toggle' id='chkToggle2' type='checkbox' data-on='Se puede Reservar' data-off='No se puede Reservar' data-width='95' name='reservable' checked>
            
      <?php endif; ?>
    </div>
  </div>

  <div class="form-row text-center">
    <div class="form-group col-md-12 ">
      <label for="inputZip">Descripcion</label>
      <textarea disabled cols="70" class="form-control" name="descripcion" id="inputObservaciones"><?php echo e($aula->descripcion); ?></textarea>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsFooter'); ?>
<!-- Para el switch (input tipo checkbox) de si un aula es reservable o no-->
<link href="<?php echo e(asset('css/bootstrap4-toggle-3.6.1.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/bootstrap4-toggle-3.6.1.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>