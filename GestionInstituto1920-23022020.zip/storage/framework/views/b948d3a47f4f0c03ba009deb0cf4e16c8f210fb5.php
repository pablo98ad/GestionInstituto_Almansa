<?php $__env->startSection('titulo'); ?>
Reservar Aula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<style>
  

  .imagenResul {
    width: 50px;
    margin: 0px;
    padding: 0px;
    padding-right: 5px;
    float:left;
  }
  .resulDiv{
    height: 50px;
    overflow: auto;
  }
  .nombreResul {
    top: 0px;
    display: inline;
    font-size: 15px;
    margin: 0px;
    padding: 0px;
  }
  .segundaLineaResul {
    display: inline;
    font-size: 10px;
    margin: 0px;
    padding: 0px;
  }
  #filtro{
    font-size: 18px;
  }
  .botonReservar{
    text-decoration: none;
    padding: 2px;
    padding-left: 3px;
    padding-right: 3px;
    font-family: helvetica;
    font-weight: 300;
    font-size: 1.3em;
    font-style: italic;
    color: #002215;
    background-color: #82b085;
    border-radius: 2px;
    border: 3px double #006505;
  }
  .botonReservar:hover{
    opacity: 0.6;
    text-decoration: none;
  }
  

</style>
<!-- Para que se vea 'bonita' la tabla de los horarios -->
<link rel="stylesheet" href="<?php echo e(asset('css/tablaHorarios.css')); ?>">
<!-- Para el select personalizado -->
<link href="<?php echo e(asset('css/select2-4.0.13.min.css')); ?>" rel="stylesheet" />
<script src="<?php echo e(asset('js/select2-4.0.13.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page">Reservas</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-md text-center">
<?php $__env->startSection('tituloCabezera'); ?> 
Reservar Aula
<?php $__env->stopSection(); ?>
  <div class="row justify-content-between">
  <a  class='col-4 col-sm-2 col-md-2  h-50 w-25  btn btn-success mb-1 mr-2' href="<?php echo e(url('/').'/reservas/listado'); ?>" role='button'>Listado</a>
  <a  class='col-5 col-sm-2 col-md-2  btn btn-danger mb-1 mr-2' href="<?php echo e(url('/').'/reservarManualmente'); ?>" role='button'>Añadir Manualmente (no recomendado)</a>
  </div>
  <div class="row d-flex justify-content-center">

    <div class="col-12 col-md-4">
      <label for="campos">Aulas con horas disponibles para reservar para la <b>semana que viene</b>:</label><br>
      <select class="w-100" id="aulasDis" disabled name="aulasDis">
        <option value="no" selected></option>
      </select>
    </div>
  </div>
  <hr>

  <div id="tabla"></div>

</div>

<script>
  let directorioBase='<?php echo e(url('/')); ?>';
  let url = directorioBase+'/api/getAulasDisponibles';

  $('#aulasDis').select2({
    placeholder: "Cargando..."
  });

  /////
  fetch(url) //pedimos a nuestra api la lista completa de las aulas disponibles con horas para reservar
    .then(response => {
      if (!response.ok) {
        document.getElementById('tabla').innerHTML = 'ERROR: ' + response.statusText;
        throw new Error('Problema con el fichero!!');
      }
      return response.json(); //pasamos de json a array de objetos...
    })
    .then(datos => {
      document.getElementById('aulasDis').disabled = false;
      //IMPORTANTISIMO, para poder buscar, introduce un nuevo campo en los objetos llamado text que se usara para la busqueda
      var datos = $.map(datos, function(obj) {
        obj.text = obj.text || (obj.nombre); // replace name with the property used for the text
        return obj;
      });
      console.log(datos);
      $('#aulasDis').select2({
        //le inidicamos el array de objeto que queremos que carge en el select
        data: datos,
        //para cuando se seleccione uno, que se muestra en el select cerrado
        templateSelection: function(result) {
          if (result.id != 'no') {
            return 'Aula: '+result.nombre + ' (ID: ' + result.id + ') ';
          }
        },
        //Para que decidamos como se ve en el menu desplegable
        templateResult: function(result) {
          if (result.id == 'no' || typeof result.id == 'undefined') { //para que no haga nada cuando es el 1º resultado
            return '';
          } else{
            var final = `<div class="resulDiv"><h2 class="nombreResul"> Nombre: ${result.nombre}  Numero: ${result.numero}    (ID: ${result.id}) </h2><br>
                                    <h3 class="segundaLineaResul"> Desc: ${result.descripcion}   (Reservable: ${result.reservable}) </h3>
                                    </div>`;
          }
          return final;
        },
        escapeMarkup: function(result) {
          return result;
        },

        //Para cambiar los textos al castellano
        language: {
          noResults: function() {
            return "No se ha encontrado.";
          },
          searching: function() {
            return "Buscando..";
          }
        }
      });
    });

    function formato(item) {
    alert(item);
    return item.nombre;
    };


  $('#aulasDis').on('select2:select', function(e) { //Para que cuando seleccionemos un option del select, se carge la horas disponibles del aula correspondientes
    cargarTabla(e);
  });





  //Para que cuando seleccionemos un option del select, se carge la horas disponibles del aula correspondiente
  function cargarTabla(e) {
    //alert(this.value);
    if (document.getElementById('aulasDis').value != 'no') {
      let aula = document.getElementById('aulasDis').value;
      let url = directorioBase + '/reservar/aula/'+aula;
      //alert(url);
      $("#tabla").load(url);
    } else {
      $("#tabla").html(' ');
    }
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>