<?php $__env->startSection('titulo'); ?>
Listado de Anuncios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<!-- Para el Date time ranger picker del rengo de fechas del anuncio-->
<script type="text/javascript" src="<?php echo e(asset('js/moment-2.18.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/daterangepicker-3.14.1.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/daterangepicker-3.14.1.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page">Anuncios</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-XL pl-4 text-center">
  <?php $__env->startSection('tituloCabezera'); ?>  
    LISTADO DE ANUNCIOS
  <?php $__env->stopSection(); ?>
  <div class="row justify-content-between">
  <form class="form-inline my-2 my-lg-0" action="<?php echo e(url('/anuncios')); ?>" role="search" method="get">
    <!--csrf_field()-->
      <input class="form-control mr-sm-2" type="text" name="busqueda" placeholder="Buscar" aria-label="Search">
      <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
    <a class='col-3 col-sm-2 col-md-2  btn btn-success mb-1 mr-2' href="<?php echo e(url('anuncios/').'/create'); ?>" role='button'><i class="fa fa-plus" aria-hidden="true"></i></a>
  </div>
  <div class="row">
    <?php foreach ($anuncios as $anuncio) { ?>

      <div class="card col-md-6 col-sm-6 col-12 mt-1 ">
        <div class="card-body  ">
          <h2 class="card-title"><?php echo e($anuncio->nombre); ?></h2>
          <?php
          if ($anuncio->activo == true) {
            echo "<span class='p-2 w-50 badge badge-warning'>Activo</span>";
          } else {
            echo "<span class='p-2 w-50 badge badge-secondary'>No Activo</span>";
          }
          ?>
          <h5 class="card-title mt-3 ">Descripción</h5>
          <div style="height: 200px;" class="border overflow-auto">
            <!--<p class="card-text">--><?php echo $anuncio->descripcion; ?>

            <!--</p>-->
          </div><br>

          <input readonly="readonly" type="text" class="form-control" name="rangos" id="rango<?php echo e($anuncio->id); ?>" />
          <script>
            $(function() {
              $('#rango<?php echo e($anuncio->id); ?>').daterangepicker({
                timePicker: true,
                startDate: moment('<?php echo e(substr($anuncio->inicio,0,16)); ?>') /*moment().startOf('hour')*/ ,
                endDate: moment('<?php echo e(substr($anuncio->fin,0,16)); ?>') /*moment().startOf('hour').add(32, 'hour')*/ ,
                locale: {
                  separator: ' a ',
                  format: 'YYYY-MM-DD HH:mm',
                  "applyLabel": "Aceptar",
                  "cancelLabel": "Cancelar",
                  "fromLabel": "De",
                  "toLabel": "a",
                  "customRangeLabel": "Custom",
                  "weekLabel": "W",
                  "daysOfWeek": [
                    "DOM",
                    "LUN",
                    "MAR",
                    "MIE",
                    "JUE",
                    "VIE",
                    "SAB"
                  ],
                  "monthNames": [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Septiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                  ],
                  "firstDay": 1
                },

                "alwaysShowCalendars": true,
                "autoApply": false,
                "timePickerIncrement": 5,
                "timePicker24Hour": true,
                "opens": "right",
                "drops": "up"

              });
            });
          </script>
          <br>


          <!--<a class='btn btn-primary' href='aulas/<?php echo e($anuncio->id); ?>' role='button'>Visualizar</a>-->
          <a class='btn btn-primary' href='anuncios/<?php echo e($anuncio->id); ?>/edit' role='button'>Editar</a>
          <div class="d-inline">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($anuncio->id); ?>">
              Eliminar
            </button>
            <!-- Modal -->
            <div class="modal fade " id="exampleModal-<?php echo e($anuncio->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog " role="document">
                <div class="modal-content ">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar el anuncio seleccionado?</h5>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                    <form class="d-inline" method="POST" action="<?php echo e(url('anuncios/').'/'.$anuncio->id); ?>">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    <?php } ?>
  </div>
  <br><br>
  <div class="row text-center d-flex justify-content-center">
    <?php echo e($anuncios->links()); ?>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>