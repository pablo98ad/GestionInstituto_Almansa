<?php $__env->startSection('titulo'); ?>
Crear un nuevo profesor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('profesores/')); ?>">Profesores</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page">Añadir</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container text-center ">
<?php $__env->startSection('tituloCabezera'); ?> 
  Formulario Añadir Profesor
<?php $__env->stopSection(); ?>
  <form class="paginaFormulario" action="<?php echo e(url('profesores')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <input type="hidden" class="form-control" name="id">

    <div class="form-row">
      <div class="form-group col-md-4">
        <label for="inputEmail4">Nombre</label>
        <input type="name" class="form-control" name="nombre" id="inputEmail4" required>
      </div>
      <div class="form-group col-md-4">
        <label for="inputPassword4">Apellidos</label>
        <input type="apellidos" class="form-control" name="apellidos" id="inputPassword4" required>
      </div>
      <div class="form-group col-md-4">
        <label for="inputAddress">Departamento</label>
        <input type="text" class="form-control" name="departamento" id="inputAddress"required>
      </div>
    </div>

    <div class="form-row ">
      <div class="form-group col-md-4">
        <label for="inputAddress2">Especialidad</label>
        <input type="text" class="form-control" name="especialidad" id="inputAddress2">
      </div>
      <div class="form-group col-md-4">
        <label for="inputCity">Cargo</label>
        <input type="text" class="form-control" name="cargo" id="inputCity">
      </div>
      <div class="form-group col-md-4">
        <label for="inputZip">Codigo</label>
        <input type="text" class="form-control" name="codigo" id="inputCod" required>
      </div>
      <div class="form-group col-md-12 ">
        <label for="inputZip">Observaciones</label>
        <textarea cols="70" class="form-control" name="observaciones" id="inputObservaciones"></textarea>
      </div>
      <div class="form-group col-md-12 text-center border ">
        <label for="exampleFormControlFile1 d-block">Subir imagen (opcional)</label><br><br>
        <input type="file" name="imagenProfesor" class="d-inline w-25 form-control-file" id="exampleFormControlFile1">
      </div>

    </div>
    <button type="submit" class="btn btn-primary">Añadir</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>