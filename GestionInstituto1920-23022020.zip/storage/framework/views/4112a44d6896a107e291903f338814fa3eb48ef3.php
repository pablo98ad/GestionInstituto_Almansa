<?php $__env->startSection('titulo'); ?>
Listado Reservas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<style>
  .pull-left {
    float: left !important;
  }

  .dataTables_filter {
    text-align: left !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('reservar/')); ?>">Reservas</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page">Listado</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-XL  pl-4 text-center">
  <!--Estoy en la vista que se ha llamado a traves del metodo listado de reservas controller -->
  <?php $__env->startSection('tituloCabezera'); ?>
  LISTADO DE RESERVAS ACTIVAS
  <?php $__env->stopSection(); ?>

  <div class="row text-center d-flex justify-content-center">
    <table id="tabla" class=" col-12 " style="width:100%">
      <thead>
        <tr>
          <th>Profesor</th>
          <th>Aula</th>
          <th>Fecha</th>
          <th>Dia Semana</th>
          <th>Hora</th>
          <th>Observaciones</th>
          <?php if(Auth::check()): ?>
         <!-- <th>Eliminar</th>-->
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($reserva->profesor->nombre); ?> <?php echo e($reserva->profesor->apellidos); ?></td>
          <td><?php echo e($reserva->aula->nombre); ?> (<?php echo e($reserva->aula->numero); ?>)</td>
          <td><?php echo e($reserva->fecha); ?></td>
          <td><?php echo e(obtenerDiaSemanaFecha($reserva->fecha)); ?></td>
          <td><?php echo e($reserva->hora); ?></td>
          <td><?php echo e($reserva->observaciones); ?></td>
          <?php if(Auth::check()): ?>
         <!-- <th>
            <div class="d-inline">
              
              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($reserva->id); ?>">
                Eliminar
              </button>
             
              <div class="modal fade " id="exampleModal-<?php echo e($reserva->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog " role="document">
                  <div class="modal-content ">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar la reserva seleccionado?</h5>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                      <form class="d-inline" method="POST" action="<?php echo e(url('reservas/').'/'.$reserva->id); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </th>-->
          <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

    </table>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsFooter'); ?>
<script>
  let directorioBase = '<?php echo e(url(' / ')); ?>';
  let url = directorioBase + '/api/getTodasReservas';
  $(document).ready(function() {
    $('#tabla').DataTable({
      "language": {
        "lengthMenu": "Ver _MENU_ registros por pagina",
        "zeroRecords": "No coincide con nada",
        "info": "Mostrando pagina _PAGE_ de _PAGES_",
        "infoEmpty": "No hay registros disponibles",
        "infoFiltered": "(Filtrados _MAX_ registros totales)",
        "paginate": {
          "first": "Primera",
          "last": "Ultima",
          "next": "Siguiente",
          "previous": "Anterior"
        },
        "search": "Buscar:",
        "zeroRecords": "Resgistros no encontrados",
        "searchPlaceholder": "Buscar Registros"
      },
      "pageLength": 30,
      "paging": false,
      "responsive": true,
      "columns": [{
          "responsivePriority": 1
        },
        {
          "responsivePriority": 2
        },
        {
          "responsivePriority": 3
        },
        {
          "responsivePriority": 5
        },
        {
          "responsivePriority": 4
        },
        {
          "responsivePriority": 6
        }
      ]

    });
    $('.dataTables_filter').addClass('pull-left');


  });

  /////
  /*fetch(url) //pedimos a nuestra api la lista completa de las aulas disponibles con horas para reservar
    .then(response => {
      if (!response.ok) {
        //document.getElementById('tabla').innerHTML = 'ERROR: ' + response.statusText;
        throw new Error('Problema con el fichero!!');
      }
      return response.json(); //pasamos de json a array de objetos...
    })
    .then(datos => {
      //document.getElementById('aulasDis').disabled = false;

    });*/
</script>
<?php $__env->stopSection(); ?>




<?php
function obtenerDiaSemanaFecha($date)
{
  $diaSemana = date('w', strtotime($date));
  switch ($diaSemana) {
    case 1:
      $diaSemana = 'Lunes';
      break;
    case 2:
      $diaSemana = 'Martes';
      break;
    case 3:
      $diaSemana = 'Miercoles';
      break;
    case 4:
      $diaSemana = 'Jueves';
      break;
    case 5:
      $diaSemana = 'Viernes';
      break;
    case 6:
      $diaSemana = 'Sabado';
      break;
    case 5:
      $diaSemana = 'Domingo';
      break;
  }
  return $diaSemana;
}
?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>