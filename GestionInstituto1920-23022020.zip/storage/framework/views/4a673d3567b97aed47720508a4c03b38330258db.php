<?php $__env->startSection('titulo'); ?>
Ver materia <?php echo e($materia->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<style>
  input,
  textarea {
    text-align: center;
  }

  .tablaProfesoresMateria {
    /*height: 50px !important;*/
    max-height: 150px !important;
    overflow: auto;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('materia/')); ?>">Materias</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page"><?php echo e($materia->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center ">
  <?php $__env->startSection('tituloCabezera'); ?>
  Mostrar Materia: <?php echo e($materia->nombre); ?>

  <?php $__env->stopSection(); ?>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Nombre</label>
      <input disabled type="text" class="form-control" value="<?php echo e($materia->nombre); ?>" name="nombre" id="inputEmail4">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Departamento</label>
      <input disabled type="text" class="form-control" value="<?php echo e($materia->departamento); ?>" name="departamento" id="inputPassword4">
    </div>
  </div>

  <div class="form-row text-center">
    <div class="form-group col-md-12 ">
      <label for="inputZip">Observaciones</label>
      <textarea disabled cols="70" class="form-control" name="observaciones" id="inputObservaciones"><?php echo e($materia->observaciones); ?></textarea>
    </div>
  </div>

  <div class="form-row text-center ">
    <div class="form-group col-md-12 ">
      <h5 class="card-title mt-3 text-center">Profesores que dan esta materia</h5>
      <?php if(sizeOf($profesoresQueLaDan)>0): ?>
      <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
        <?php $__currentLoopData = $profesoresQueLaDan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/profesores/'.$profe->profesor->id)); ?>"><?php echo e($profe->profesor->nombre); ?> <?php echo e($profe->profesor->apellidos); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php else: ?>
      <p class="alert-danger">Esta materia no esta en los horarios</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="form-row text-center ">
    <div class="form-group col-md-12 ">
      <h5 class="card-title mt-3 text-center">Grupos que dan esta materia</h5>
      <?php if(sizeOf($gruposQueLaDan)>0): ?>
      <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
        <?php $__currentLoopData = $gruposQueLaDan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/grupo/'.$grupo->grupo->id)); ?>"><?php echo e($grupo->grupo->nombre); ?> - <?php echo e($grupo->grupo->curso); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php else: ?>
      <p class="alert-danger">Esta materia no esta en los horarios</p>
      <?php endif; ?>
    </div>
  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>