<?php $__env->startSection('titulo'); ?>
Horario del aula <?php echo e($horariosAula['nombreAula']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<!-- Para que se vea 'bonita' la tabla de los horarios -->
<link rel="stylesheet" href="<?php echo e(asset('css/tablaHorarios.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/aulas')); ?>">Aulas</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page">Horario Aula <?php echo e($horariosAula['nombreAula']); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-md text-center">

<?php $__env->startSection('tituloCabezera'); ?>  
Horario del Aula: <?php echo e($horariosAula['nombreAula']); ?> y reservas de <b>esta semana</b>
<?php $__env->stopSection(); ?>
 <!-- <div class="row justify-content-end">
    <a class='col-3 col-sm-2 col-md-2  btn btn-success mb-1 mr-2' href="<?php echo e(url('aulas/').'/create'); ?>" role='button'>Añadir</a>
  </div>-->
  <?php if (!isset($horariosAula['L']['1'])){
    echo "<h1>No se han encontrado registros para esta tabla</h1><br>";
  }
  ?>
   <div class="row">
  
    <table class="greenTable">
      <thead>
        <tr>
          <th></th>
          <th>Lunes</th>
          <th>Martes</th>
          <th>Miercoles</th>
          <th>Jueves</th>
          <th>Viernes</th>
        </tr>
      </thead>
      <tbody>
      <tr>
      <td>1</td><td><?php echo $horariosAula['L']['1']; ?></td><td><?php echo $horariosAula['M']['1']; ?></td><td><?php echo $horariosAula['X']['1']; ?></td><td><?php echo $horariosAula['J']['1']; ?></td><td><?php echo $horariosAula['V']['1']; ?></td></tr>
      <tr>
      <td>2</td><td><?php echo $horariosAula['L']['2']; ?></td><td><?php echo $horariosAula['M']['2']; ?></td><td><?php echo $horariosAula['X']['2']; ?></td><td><?php echo $horariosAula['J']['2']; ?></td><td><?php echo $horariosAula['V']['2']; ?></td></tr>
      <tr>
      <td>3</td><td><?php echo $horariosAula['L']['3']; ?></td><td><?php echo $horariosAula['M']['3']; ?></td><td><?php echo $horariosAula['X']['3']; ?></td><td><?php echo $horariosAula['J']['3']; ?></td><td><?php echo $horariosAula['V']['3']; ?></td></tr>
      <tr>
      <td>R</td><td><?php echo $horariosAula['L']['R']; ?></td><td><?php echo $horariosAula['M']['R']; ?></td><td><?php echo $horariosAula['X']['R']; ?></td><td><?php echo $horariosAula['J']['R']; ?></td><td><?php echo $horariosAula['V']['R']; ?></td></tr>
      <tr>
      <td>4</td><td><?php echo $horariosAula['L']['4']; ?></td><td><?php echo $horariosAula['M']['4']; ?></td><td><?php echo $horariosAula['X']['4']; ?></td><td><?php echo $horariosAula['J']['4']; ?></td><td><?php echo $horariosAula['V']['4']; ?></td></tr>
      <tr>
      <td>5</td><td><?php echo $horariosAula['L']['5']; ?></td><td><?php echo $horariosAula['M']['5']; ?></td><td><?php echo $horariosAula['X']['5']; ?></td><td><?php echo $horariosAula['J']['5']; ?></td><td><?php echo $horariosAula['V']['5']; ?></td></tr>
      <tr>
      <td>6</td><td><?php echo $horariosAula['L']['6']; ?></td><td><?php echo $horariosAula['M']['6']; ?></td><td><?php echo $horariosAula['X']['6']; ?></td><td><?php echo $horariosAula['J']['6']; ?></td><td><?php echo $horariosAula['V']['6']; ?></td></tr>
      <tr>
      <td>7</td><td><?php echo $horariosAula['L']['1']; ?></td><td><?php echo $horariosAula['M']['7']; ?></td><td><?php echo $horariosAula['X']['7']; ?></td><td><?php echo $horariosAula['J']['7']; ?></td><td><?php echo $horariosAula['V']['7']; ?></td></tr>
      </tbody>
      </tr>
    </table>
   </div>
 
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>