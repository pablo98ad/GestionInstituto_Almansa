<?php
    if(sizeof($horario)>0){
    ?>
    <table class="greenTable">
      <thead>
        <tr>
          <th></th>
          <th>Lunes</th>
          <th>Martes</th>
          <th>Miercoles</th>
          <th>Jueves</th>
          <th>Viernes</th>
        </tr>
      </thead>
      <tbody>
      <tr>
      <td>1</td><td>{!!$horario['L']['1']!!}</td><td>{!!$horario['M']['1']!!}</td><td>{!!$horario['X']['1']!!}</td><td>{!!$horario['J']['1']!!}</td><td>{!!$horario['V']['1']!!}</td></tr>
      <tr>
      <td>2</td><td>{!!$horario['L']['2']!!}</td><td>{!!$horario['M']['2']!!}</td><td>{!!$horario['X']['2']!!}</td><td>{!!$horario['J']['2']!!}</td><td>{!!$horario['V']['2']!!}</td></tr>
      <tr>
      <td>3</td><td>{!!$horario['L']['3']!!}</td><td>{!!$horario['M']['3']!!}</td><td>{!!$horario['X']['3']!!}</td><td>{!!$horario['J']['3']!!}</td><td>{!!$horario['V']['3']!!}</td></tr>
      <tr>
      <td>R</td><td>{!!$horario['L']['R']!!}</td><td>{!!$horario['M']['R']!!}</td><td>{!!$horario['X']['R']!!}</td><td>{!!$horario['J']['R']!!}</td><td>{!!$horario['V']['R']!!}</td></tr>
      <tr>
      <td>4</td><td>{!!$horario['L']['4']!!}</td><td>{!!$horario['M']['4']!!}</td><td>{!!$horario['X']['4']!!}</td><td>{!!$horario['J']['4']!!}</td><td>{!!$horario['V']['4']!!}</td></tr>
      <tr>
      <td>5</td><td>{!!$horario['L']['5']!!}</td><td>{!!$horario['M']['5']!!}</td><td>{!!$horario['X']['5']!!}</td><td>{!!$horario['J']['5']!!}</td><td>{!!$horario['V']['5']!!}</td></tr>
      <tr>
      <td>6</td><td>{!!$horario['L']['6']!!}</td><td>{!!$horario['M']['6']!!}</td><td>{!!$horario['X']['6']!!}</td><td>{!!$horario['J']['6']!!}</td><td>{!!$horario['V']['6']!!}</td></tr>
      <tr>
      <td>7</td><td>{!!$horario['L']['1']!!}</td><td>{!!$horario['M']['7']!!}</td><td>{!!$horario['X']['7']!!}</td><td>{!!$horario['J']['7']!!}</td><td>{!!$horario['V']['7']!!}</td></tr>
      </tbody>
      </tr>
    </table>

    <?php
    }else{
      echo "<h1>Esta Aula no se puede reservar</h1>";
    }
    ?>

