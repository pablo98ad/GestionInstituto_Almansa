<?php
    if(sizeof($horario)>0){
    ?>
    <table class="greenTable">
      <thead>
        <tr>
          <th></th>
          <th>Lunes</th>
          <th>Martes</th>
          <th>Miercoles</th>
          <th>Jueves</th>
          <th>Viernes</th>
        </tr>
      </thead>
      <tbody>
      <tr>
      <td>1</td><td><?php echo $horario['L']['1']; ?></td><td><?php echo $horario['M']['1']; ?></td><td><?php echo $horario['X']['1']; ?></td><td><?php echo $horario['J']['1']; ?></td><td><?php echo $horario['V']['1']; ?></td></tr>
      <tr>
      <td>2</td><td><?php echo $horario['L']['2']; ?></td><td><?php echo $horario['M']['2']; ?></td><td><?php echo $horario['X']['2']; ?></td><td><?php echo $horario['J']['2']; ?></td><td><?php echo $horario['V']['2']; ?></td></tr>
      <tr>
      <td>3</td><td><?php echo $horario['L']['3']; ?></td><td><?php echo $horario['M']['3']; ?></td><td><?php echo $horario['X']['3']; ?></td><td><?php echo $horario['J']['3']; ?></td><td><?php echo $horario['V']['3']; ?></td></tr>
      <tr>
      <td>R</td><td><?php echo $horario['L']['R']; ?></td><td><?php echo $horario['M']['R']; ?></td><td><?php echo $horario['X']['R']; ?></td><td><?php echo $horario['J']['R']; ?></td><td><?php echo $horario['V']['R']; ?></td></tr>
      <tr>
      <td>4</td><td><?php echo $horario['L']['4']; ?></td><td><?php echo $horario['M']['4']; ?></td><td><?php echo $horario['X']['4']; ?></td><td><?php echo $horario['J']['4']; ?></td><td><?php echo $horario['V']['4']; ?></td></tr>
      <tr>
      <td>5</td><td><?php echo $horario['L']['5']; ?></td><td><?php echo $horario['M']['5']; ?></td><td><?php echo $horario['X']['5']; ?></td><td><?php echo $horario['J']['5']; ?></td><td><?php echo $horario['V']['5']; ?></td></tr>
      <tr>
      <td>6</td><td><?php echo $horario['L']['6']; ?></td><td><?php echo $horario['M']['6']; ?></td><td><?php echo $horario['X']['6']; ?></td><td><?php echo $horario['J']['6']; ?></td><td><?php echo $horario['V']['6']; ?></td></tr>
      <tr>
      <td>7</td><td><?php echo $horario['L']['1']; ?></td><td><?php echo $horario['M']['7']; ?></td><td><?php echo $horario['X']['7']; ?></td><td><?php echo $horario['J']['7']; ?></td><td><?php echo $horario['V']['7']; ?></td></tr>
      </tbody>
      </tr>
    </table>

    <?php
    }else{
      echo "<h1>Esta Aula no se puede reservar</h1>";
    }
    ?>

