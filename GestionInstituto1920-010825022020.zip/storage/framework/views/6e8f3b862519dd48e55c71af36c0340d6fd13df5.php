<?php $__env->startSection('titulo'); ?>
Editar aula <?php echo e($materia->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('materia/')); ?>">Materias</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page"><?php echo e($materia->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center justify-content-center ">
  <?php $__env->startSection('tituloCabezera'); ?>
  Formulario editar Materia
  <?php $__env->stopSection(); ?>
  <form id="actualizar" class="paginaFormulario text-center justify-content-center" action="<?php echo e(url('materia/').'/'.$materia->id); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label for="inputEmail4">Nombre</label>
        <input type="text" class="form-control" value="<?php echo e($materia->nombre); ?>" name="nombre" id="inputEmail4">
      </div>
      <div class="form-group col-md-6">
        <label for="inputPassword4">Departamento</label>
        <input type="text" class="form-control" value="<?php echo e($materia->departamento); ?>" name="departamento" id="inputPassword4">
      </div>
    </div>

    <div class="form-row text-center">
      <div class="form-group col-md-12 ">
        <label for="inputZip">Observaciones</label>
        <textarea cols="70" class="form-control" name="observaciones" id="inputObservaciones"><?php echo e($materia->observaciones); ?></textarea>
      </div>
    </div>

  </form>
  <button type="submit" name="enviar" form="actualizar" class="btn btn-primary">Guardar</button>
  <div class="d-inline">
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($materia->id); ?>">
      Eliminar
    </button>
    <!-- Modal -->
    <div class="modal fade " id="exampleModal-<?php echo e($materia->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog " role="document">
        <div class="modal-content ">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar la materia seleccionada?</h5>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <form class="d-inline" method="POST" action="<?php echo e(url('materia/').'/'.$materia->id); ?>">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('DELETE')); ?>

              <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>