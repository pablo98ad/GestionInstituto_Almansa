<?php $__env->startSection('titulo'); ?>
Editar Profesor <?php echo e($profesor->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('profesores/')); ?>">Profesores</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page"><?php echo e($profesor->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container text-center ">
  <?php $__env->startSection('tituloCabezera'); ?>
  Formulario actualizar profesor: <?php echo e($profesor->nombre); ?>

  <?php $__env->stopSection(); ?>
  <hr><br>
  <form class="paginaFormulario" action="<?php echo e(url('profesores/').'/'.$profesor->id); ?>" id="actualizar" enctype="multipart/form-data" method="POST">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <input type="hidden" class="form-control" name="_method" value="PUT">

    <input type="hidden" class="form-control" name="id" value="<?php echo e($profesor->id); ?>">

    <div class="form-row">
      <div class="form-group col-md-4">
        <label for="inputEmail4">Nombre</label>
        <input type="name" class="form-control" name="nombre" value="<?php echo e($profesor->nombre); ?>" id="inputEmail4">
      </div>
      <div class="form-group col-md-4">
        <label for="inputPassword4">Apellidos</label>
        <input type="apellidos" class="form-control" name="apellidos" value="<?php echo e($profesor->apellidos); ?>" id="inputPassword4">
      </div>
      <div class="form-group col-md-4">
        <label for="inputAddress">Departamento</label>
        <input type="text" class="form-control" name="departamento" value="<?php echo e($profesor->departamento); ?>" id="inputAddress">
      </div>
    </div>

    <div class="form-row ">
      <div class="form-group col-md-4">
        <label for="inputAddress2">Especialidad</label>
        <input type="text" class="form-control" name="especialidad" value="<?php echo e($profesor->especialidad); ?>" id="inputAddress2">
      </div>
      <div class="form-group col-md-4">
        <label for="inputCity">Cargo</label>
        <input type="text" class="form-control" name="cargo" value="<?php echo e($profesor->cargo); ?>" id="inputCity">
      </div>
      <div class="form-group col-md-4">
        <label for="inputZip">Codigo</label>
        <input type="text" class="form-control" name="codigo" value="<?php echo e($profesor->codigo); ?>" id="inputCod">
      </div>
      <div class="form-group col-md-12 ">
        <label for="inputZip">Observaciones</label>
        <textarea cols="70" class="form-control" name="observaciones" id="inputObservaciones"><?php echo e($profesor->observaciones); ?></textarea>
      </div>
      <div class="form-group col-md-12 ">
        <?php if(substr($profesor->rutaImagen, -11, 12) != 'default.png'): ?>
        <!--comprobamos si tiene la foto por defecto-->
        <img class="d-inline border" width="250px" src="<?php echo e(url('/').'/storage/'.$profesor->rutaImagen/*url('../').'/storage/app/public/'.$profesor->rutaImagen*/); ?>" alt="">
        <?php endif; ?>
        <input type="file" name="imagenProfesor" class="d-inline w-25 form-control-file" id="exampleFormControlFile1">
      </div>

    </div>

  </form>
  <hr>
  <button type="submit" name="enviar" form="actualizar" class="btn btn-primary">Guardar</button>
  <div class="d-inline">
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($profesor->id); ?>">
    <i class="fa fa-trash" aria-hidden="true"></i>
    </button>
    <!-- Modal -->
    <div class="modal fade " id="exampleModal-<?php echo e($profesor->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog " role="document">
        <div class="modal-content ">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar el profesor seleccionads?</h5>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <form class="d-inline" method="POST" action="<?php echo e(url('profesores/').'/'.$profesor->id); ?>">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('DELETE')); ?>

              <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
            </form>
          </div>
        </div>
      </div>
    </div>
    <!--<form class="d-inline" method="POST" action="<?php echo e(url('profesores/').'/'.$profesor->id); ?>">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('DELETE')); ?>

      <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
    </form>-->
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>