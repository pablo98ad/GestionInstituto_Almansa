<?php $__env->startSection('titulo'); ?>
Listado de alumnos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page">Alumnos</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-XL pl-4 text-center">
  <?php $__env->startSection('tituloCabezera'); ?>
  LISTADO DE ALUMNOS
  <?php $__env->stopSection(); ?>
  <div class="row justify-content-between">
  <form class="form-inline my-2 my-lg-0" action="<?php echo e(url('/alumno')); ?>" role="search" method="get">
      <input class="form-control mr-sm-1" type="text" name="busqueda" placeholder="Buscar" aria-label="Search">
      <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-search " aria-hidden="true"></i></button>
    </form>
    <?php if(Auth::check()): ?>
    <!-- MODAL PARA LA IMPORTACION  DE PROFESORES POR FICHERO -->
    <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap">Importar</button>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Importar Alumnos</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form id="myform" action="<?php echo e(url('alumno/importar')); ?>" enctype="multipart/form-data" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label for="exampleFormControlFile1">Subir fichero XML con alumnos</label>
                <input type="file" name="ficheroProfesores" class="form-control-file" id="exampleFormControlFile1" required>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button form="myform" type="submit" class="btn btn-primary">Subir Fichero</button>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>


    <?php if(Auth::check()): ?>
    <a class='col-3 col-sm-2 col-md-2  btn btn-info mb-1 mr-2' href="<?php echo e(url('alumno/').'/create'); ?>" role='button'><i class="fa fa-plus" aria-hidden="true"></i></a>
    <?php endif; ?>

  </div>
  <div class="row mt-2 ">
    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card col-md-3 col-sm-6 col-12 mt-1 ">
      <div class="card-body m-0 p-0 mt-2 mb-2">
        <h2 class="card-title d-inline"><?php echo e($alumno->nombre); ?></h2>
        <img draggable="false" class="card-img-top w-25 d-inline border mb-1" src="<?php echo e(url('/').'/storage/'.$alumno->rutaImagen/*url('../').'/storage/app/public/'.$profesor->rutaImagen*/); ?>" alt="">
        <h5 class="card-subtitle mb-2 text-muted"><?php echo e($alumno->apellidos); ?></h5>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <!--<th scope="col">ID</th>-->
                <th scope="col">Grupo</th>
                <th scope="col">Edad</th>
                <th scope="col">Telefono 1</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <!--<td><?php echo e($alumno->id); ?></td>-->
                <td><?php echo e($alumno->grupo->nombre); ?></td>
                <td><?php echo e(floor((time() - strtotime($alumno->fechaNacimiento)) / 31556926)); ?></td>
                <td><?php echo e($alumno->Telefono1); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <h5 class="card-title ">Observaciones</h5>
        <div style="height: 80px;" class="border overflow-auto">
          <p class="card-text"><?php echo e($alumno->observaciones); ?></p>
        </div><br>
        <a class='btn btn-success' href='alumno/<?php echo e($alumno->id); ?>' role='button'>Ver</a>
        <!--<a class='btn btn-warning' href='horario/alumno/<?php echo e($alumno->id); ?>' role='button'>Horario</a>-->
        <?php if(Auth::check()): ?>
        <a class='btn btn-primary' href='alumno/<?php echo e($alumno->id); ?>/edit' role='button'>Editar</a>
        <div class="d-inline">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($alumno->id); ?>">
          <i class="fa fa-trash" aria-hidden="true"></i>
          </button>
          <!-- Modal -->
          <div class="modal fade " id="exampleModal-<?php echo e($alumno->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog " role="document">
              <div class="modal-content ">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar el alumno seleccionads?</h5>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                  <form class="d-inline" method="POST" action="<?php echo e(url('alumno/').'/'.$alumno->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(sizeOf($alumnos)==0): ?>
      <h3 class='text-center w-100 mt-4'>No hay resultados</h3>
    <?php endif; ?>

  </div><br><br>
  <div class="row text-center d-flex justify-content-center">
    <?php echo e($alumnos->links()); ?>

  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>