<?php $__env->startSection('titulo'); ?>
Ver grupo <?php echo e($grupo->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<style>
  input,
  textarea {
    text-align: center;
  }

  .tablaProfesoresMateria {
    /*height: 50px !important;*/
    max-height: 150px !important;
    overflow: auto;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('grupo/')); ?>">Grupos</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page"><?php echo e($grupo->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center ">
  <?php $__env->startSection('tituloCabezera'); ?>
  Mostrar Grupo: <?php echo e($grupo->nombre); ?>

  <?php $__env->stopSection(); ?>

  <div class="form-row">
    <div class="form-group col-md-12">
      <label for="inputEmail4">Nombre</label>
      <input disabled type="text" class="form-control" value="<?php echo e($grupo->nombre); ?>" name="nombre" id="inputEmail4">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Curso</label>
      <input disabled type="text" class="form-control" value="<?php echo e($grupo->curso); ?>" name="curso" id="inputPassword4">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Nombre Tutor</label>
      <input disabled type="text" class="form-control" value="<?php echo e($grupo->nombreTutor); ?>" name="nombreTutor" id="inputPassword4">
    </div>
  </div>

  <div class="form-row text-center">
    <div class="form-group col-md-12 ">
      <label for="inputZip">Descripcion</label>
      <textarea disabled cols="70" class="form-control" name="descripcion" id="inputObservaciones"><?php echo e($grupo->descripcion); ?></textarea>
    </div>
  </div>

  <div class="form-row text-center ">
    <div class="form-group col-md-12 ">
      <h5 class="card-title mt-3 text-center">Profesores que dan a este grupo</h5>
      <?php if(sizeOf($profesoresQueLeDan)>0): ?>
      <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
        <?php $__currentLoopData = $profesoresQueLeDan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/profesores/'.$profe->profesor->id)); ?>"><?php echo e($profe->profesor->nombre); ?> <?php echo e($profe->profesor->apellidos); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php else: ?>
      <p class="alert-danger">Este grupo no esta en los horarios</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="form-row text-center ">
    <div class="form-group col-md-12 ">
      <h5 class="card-title mt-3 text-center">Materias del grupo</h5>
      <?php if(sizeOf($materiasQueDan)>0): ?>
      <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
        <?php $__currentLoopData = $materiasQueDan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/materia/'.$materia->materia->id)); ?>"><?php echo e($materia->materia->nombre); ?> - <?php echo e($materia->materia->departamento); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php else: ?>
      <p class="alert-danger">Este Grupo no esta en los horarios</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="form-row text-center ">
    <div class="form-group col-md-12 ">
      <h5 class="card-title mt-3 text-center">Alumnos del grupo</h5>
      <?php if(sizeOf($alumnosGrupo)>0): ?>
      <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
        <?php $__currentLoopData = $alumnosGrupo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/alumno/'.$alum->id)); ?>"><?php echo e($alum->nombre); ?> <?php echo e($alum->apellidos); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php else: ?>
      <p class="alert-danger">Este Grupo no esta en los horarios</p>
      <?php endif; ?>
    </div>
  </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>