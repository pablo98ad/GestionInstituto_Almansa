<?php $__env->startSection('titulo'); ?>
Crear un nuevo grupo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('materia/')); ?>">Grupos</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page">Añadir</li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container text-center justify-content-center ">
<?php $__env->startSection('tituloCabezera'); ?>   
Formulario Añadir Grupo
<?php $__env->stopSection(); ?>
  <form class="paginaFormulario text-center justify-content-center" action="<?php echo e(url('grupo')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>


    <div class="form-row">
      <div class="form-group col-md-12">
        <label for="inputEmail4">Nombre</label>
        <input type="text" class="form-control" name="nombre" id="inputEmail4" required>
      </div>
      <div class="form-group col-md-6">
        <label for="inputPassword4">Curso</label>
        <input type="text" class="form-control" name="curso" id="inputPassword4" required>
      </div>
      <div class="form-group col-md-6">
        <label for="inputPassword4">Nombre Tutor</label>
        <input type="text" class="form-control" name="nombreTutor" id="inputPassword4" required>
      </div>
    </div>


    <div class="form-row text-center">
      <div class="form-group col-md-12 ">
        <label for="inputObservaciones">Descripcion</label>
        <textarea cols="70" maxlength="50" class="form-control" name="descripcion" id="inputObservaciones" required></textarea>
      </div>
    </div>

    <button type="submit" class="btn btn-primary">Añadir</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>