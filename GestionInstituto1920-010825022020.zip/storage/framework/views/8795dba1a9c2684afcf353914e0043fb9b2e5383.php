<?php $__env->startSection('titulo'); ?>
Listado de materias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item d-inline"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="breadcrumb-item active d-inline" aria-current="page">Materias</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-XL pl-4 text-center">
  <?php $__env->startSection('tituloCabezera'); ?>
  LISTADO DE MATERIAS
  <?php $__env->stopSection(); ?>
  <div class="row justify-content-between">
    <form class="form-inline my-2 my-lg-0" action="<?php echo e(url('/materia')); ?>" role="search" method="get">
      <!--csrf_field()-->
      <input class="form-control mr-sm-2" type="text" name="busqueda" placeholder="Buscar" aria-label="Search">
      <button class="btn btn-success my-2 my-sm-0" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>

    <?php if(Auth::check()): ?>
    <a class='col-3 col-sm-2 col-md-2  btn btn-success mb-1 mr-2' href="<?php echo e(url('materia/').'/create'); ?>" role='button'><i class="fa fa-plus" aria-hidden="true"></i></a>
    <?php endif; ?>
  </div>
  <div class="row mt-2">
    <?php $__currentLoopData = $materias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-md-3 col-sm-6 col-12 mt-1 ">
      <div class="card-body  ">
        <h2 class="card-title"><?php echo e($materia->nombre); ?></h2>
        <h4 class="card-subtitle mb-2 text-muted"><?php echo e($materia->numero); ?></h4>

        <h5 class="card-title  ">Departamento</h5>

          <p class="card-text"><?php echo e($materia->departamento); ?></p>

        <h5 class="card-title mt-3 ">Observaciones</h5>
        <div style="height: 55px;" class="border overflow-auto">
          <p class="card-text"><?php echo e($materia->observaciones); ?></p>
        </div><br>

        <a class='btn btn-success' href='materia/<?php echo e($materia->id); ?>' role='button'>Ver</a>
        <?php if(Auth::check()): ?>
        <a class='btn btn-primary' href='materia/<?php echo e($materia->id); ?>/edit' role='button'>Editar</a>
        <div class="d-inline">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal-<?php echo e($materia->id); ?>">
          <i class="fa fa-trash" aria-hidden="true"></i>
          </button>
          <!-- Modal -->
          <div class="modal fade " id="exampleModal-<?php echo e($materia->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog " role="document">
              <div class="modal-content ">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">AVISO</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <h5 class="modal-title" id="exampleModalLabel">¿Esta seguro que quiere eliminar la materia seleccionada?</h5>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                  <form class="d-inline" method="POST" action="<?php echo e(url('materia/').'/'.$materia->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="submit" name="eliminar" class="btn btn-danger" value="Eliminar">
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <br><br>
  <div class="row text-center d-flex justify-content-center">
    <?php echo e($materias->links()); ?>

  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>