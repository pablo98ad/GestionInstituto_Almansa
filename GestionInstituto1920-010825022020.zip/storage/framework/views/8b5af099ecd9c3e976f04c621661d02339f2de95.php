<?php $__env->startSection('titulo'); ?>
Ver Alumno <?php echo e($alumno->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Instituto</a></li>
<li class="d-inline breadcrumb-item"><a href="<?php echo e(url('alumno/')); ?>">Alumnos</a></li>
<li class="d-inline breadcrumb-item active" aria-current="page"><?php echo e($alumno->nombre); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsHead'); ?>
<!-- Para el Date  picker de la edad del alumno-->
<script type="text/javascript" src="<?php echo e(asset('js/moment-2.18.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/daterangepicker-3.14.1.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/daterangepicker-3.14.1.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tituloCabezera'); ?>
Mostrar Alumno <?php echo e($alumno->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container text-center ">
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="nombre">Nombre</label>
      <input disabled type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e($alumno->nombre); ?>">
    </div>
    <div class="form-group col-md-4">
      <label for="apellidos">Apellidos</label>
      <input disabled type="text" class="form-control" name="apellidos" id="apellidos" value="<?php echo e($alumno->apellidos); ?>">
    </div>
    <div class=" col-md-4">
      <div class="row d-flex justify-content-center ">
        <div id="divSelectGrupos" class="col-12">
          <label for="grudpos">Grupo</label><br>
          <input disabled type="text" class="form-control" name="grupos" id="grudpos" value="<?php echo e($alumno->grupo->nombre); ?> - <?php echo e($alumno->grupo->curso); ?>">

        </div>
      </div>
    </div>
  </div>

  <div class="form-row ">
    <div class="form-group col-md-3">
      <label for="fechaNacimiento">Fecha de Nacimiento</label>
      <input readonly type="text" value="<?php echo e($alumno->fechaNacimiento); ?>" class="form-control" name="fechaNacimiento" id="fechaNacimiento" required />
      <script>
        $(function() {
          $('#fechaNacimiento').daterangepicker({
            "singleDatePicker": true,
            "locale": {
              "format": 'YYYY-MM-DD',
              "applyLabel": "Aceptar",
              "cancelLabel": "Cancelar",
              "customRangeLabel": "Custom",
              "weekLabel": "W",
              "daysOfWeek": [
                "DOM",
                "LUN",
                "MAR",
                "MIE",
                "JUE",
                "VIE",
                "SAB"
              ],
              "monthNames": [
                "Enero",
                "Febrero",
                "Marzo",
                "Abril",
                "Mayo",
                "Junio",
                "Julio",
                "Agosto",
                "Septiembre",
                "Octubre",
                "Noviembre",
                "Diciembre"
              ],
              "firstDay": 1
            },
            "alwaysShowCalendars": true,
            "autoApply": false,
            "opens": "right",
            "drops": "down",
            "showDropdowns": true,
          });
        });
      </script>

    </div>
    <div class="form-group col-md-1">
      <label for="telefono1">Edad</label>
      <input readonly type="text" value="<?php echo e(floor((time() - strtotime($alumno->fechaNacimiento)) / 31556926)); ?>" class="form-control" name="fechaNacimiento" id="fechaNacimiento" required />

    </div>

    <div class="form-group col-md-4">
      <label for="telefono1">Telefono 1</label>
      <input disabled type="text" class="form-control" name="telefono1" id="telefono1" value="<?php echo e($alumno->Telefono1); ?>">
    </div>
    <div class="form-group col-md-4">
      <label for="telefono2">Telefono 2</label>
      <input disabled type="text" class="form-control" name="telefono2" id="telefono2" value="<?php echo e($alumno->Telefono1); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="nombrePadre">Nombre del Padre</label>
      <input disabled type="text" class="form-control" name="nombrePadre" id="nombrePadre" value="<?php echo e($alumno->nombrePadre); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="nombreMadre">Nombre de la Madre</label>
      <input disabled type="text" class="form-control" name="nombreMadre" id="nombreMadre" value="<?php echo e($alumno->nombreMadre); ?>">
    </div>
    <div class="form-group col-md-8 ">
      <label for="observaciones">Observaciones</label>
      <textarea disabled cols="70" class="form-control" name="observaciones" id="observaciones"><?php echo e($alumno->observaciones); ?></textarea>
    </div>
    <div class="form-group col-md-4 ">
      <label for="observaciones">Imagen</label><br>
      <img draggable="false" class="d-inline border" width="150px" src="<?php echo e(url('/').'/storage/'.$alumno->rutaImagen/*url('../').'/storage/app/public/'.$alumno->rutaImagen*/); ?>" alt="">


    </div>
  </div>
    <div class="form-row text-center ">
      <div class="form-group col-md-12 ">
        <h5 class="card-title mt-3 text-center">Compañeros de Grupo</h5>
        <?php if(sizeOf($companeros)>0): ?>
        <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
          <?php $__currentLoopData = $companeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url('/alumno/').'/'.$compa->id); ?>"><?php echo e($compa->nombre); ?> <?php echo e($compa->apellidos); ?></a><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p class="alert-danger">Este grupo donde esta el alumno no esta en los horarios</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="form-row text-center ">
      <div class="form-group col-md-12 ">
        <h5 class="card-title mt-3 text-center">Profesores que le dan clase</h5>
        <?php if(sizeOf($profes)>0): ?>
        <div class="tablaProfesoresMateria rounded mx-auto w-50 text-center bg-warning">
          <?php $__currentLoopData = $profes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url('/profesores/').'/'.$profe->profesor->id); ?>"><?php echo e($profe->profesor->nombre); ?> - <?php echo e($profe->profesor->apellidos); ?></a><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p class="alert-danger">Este grupo donde esta el alumno no esta en los horarios</p>
        <?php endif; ?>
      </div>
    </div>
  


  <hr>
  <a class='btn btn-warning' href='<?php echo e(url('/horario/alumno/').'/'.$alumno->id); ?>' role='button'>Horario</a>
  <a class='btn btn-primary' href='<?php echo e($alumno->id); ?>/edit' role='button'>Editar</a>
  <!--<a class='btn btn-danger' href="<?php echo e(route('alumno.destroy', [$alumno->id])); ?>" role='button'>Borrar</a>-->
  <div class="d-inline">
    <form class="d-inline" method="POST" action="<?php echo e(url('alumno/').'/'.$alumno->id); ?>">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('DELETE')); ?>

      <input type="submit" class="btn btn-danger" value="Eliminar">
    </form>
  </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>