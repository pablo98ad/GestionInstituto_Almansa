<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ausencias extends Model
{
    //
    protected $table = 'ausencias';

}
